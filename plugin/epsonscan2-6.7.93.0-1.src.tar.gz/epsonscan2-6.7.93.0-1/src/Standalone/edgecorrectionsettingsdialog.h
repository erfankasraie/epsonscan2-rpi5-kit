#ifndef EDGECORRECTIONSETTINGSDIALOG_H
#define EDGECORRECTIONSETTINGSDIALOG_H

#include <QDialog>
#include "supervisor.h"
#include "translationstring.h"


namespace Ui {
class EdgeCorrectionSettingsDialog;
}

class EdgeCorrectionSettingsDialog : public QDialog
{
    Q_OBJECT

public:
    explicit EdgeCorrectionSettingsDialog(SCANPARA device_data, QWidget *parent = 0);
    ~EdgeCorrectionSettingsDialog();

    void SetValue(void);
    void GetValue(SCANPARA* device_data);


private:
    Ui::EdgeCorrectionSettingsDialog *ui;
    SCANPARA m_settings;
    private:

    void updateUI(void);

};

#endif // EDGECORRECTIONSETTINGSDIALOG_H
