#ifndef AdministratorPasswordInputForUKSecurityDialog_H
#define AdministratorPasswordInputForUKSecurityDialog_H

#include <QDialog>
#include <QCloseEvent>

namespace Ui {
class AdministratorPasswordInputForUKSecurityDialog;
}

class AdministratorPasswordInputForUKSecurityDialog : public QDialog
{
    Q_OBJECT

protected:
    void closeEvent(QCloseEvent* event);

public:
    explicit AdministratorPasswordInputForUKSecurityDialog(QWidget *parent = 0);
    ~AdministratorPasswordInputForUKSecurityDialog();

    QString GetPassword();

public slots:
    void PushButtonAction(void);
    void LineEditFinished();

private:
    Ui::AdministratorPasswordInputForUKSecurityDialog *ui;

    QString m_password;
};

#endif // AdministratorPasswordInputForUKSecurityDialog_H
