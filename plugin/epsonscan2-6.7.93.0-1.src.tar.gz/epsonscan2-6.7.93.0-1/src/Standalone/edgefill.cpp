#include "mainwindow.h"
#include "edgefill.h"

EdgeFill::EdgeFill(QWidget *parent) :
    QComboBox(parent)
{
    changed = false;
    current_item = false;
}

void EdgeFill::initialize(SCANPARA edge_fill_para){
    changed = true;
    current_item = edge_fill_para.edgeFill.select;
    //this->setEnabled(true);
}

void EdgeFill::update_ui(INT_SETTING_VALUE edge_fill_para, QLabel* label1, QLabel* label2){

    label1->setText(TranslationString::GetString().translation_str.ADVANCEDSETTING_114);

    if (edge_fill_para.capability.supportLevel != kSDISupportLevelNone)
    {
        this->setVisible(true);
        label1->setVisible(true);
        label2->setVisible(true);
    }else
    {
        this->setVisible(false);
        label1->setVisible(false);
        label2->setVisible(false);
        return;
    }

    if(changed == true){
        this->clear();
        if(edge_fill_para.capability.supportLevel == kSDISupportLevelAvailable){
            this->setEnabled(true);
            label1->setVisible(true);
            label2->setVisible(true);

            this->add_item();
            this->select_item();
        }else {
            this->setEnabled(false);
            label1->setVisible(false);
            label2->setVisible(false);
        }
        changed = false;
    }
}

void EdgeFill::add_item(){

    int i = 0;
    this->insertItem(i, "None" /*TranslationString::GetString().translation_str.ADVANCEDSETTING_041*/, EdgeFillNone);
    i++;
    this->insertItem(i, "White" /*TranslationString::GetString().translation_str.ADVANCEDSETTING_042*/, EdgeFillWhite);
    i++;
    this->insertItem(i, "Black" /*TranslationString::GetString().translation_str.ADVANCEDSETTING_043*/, EdgeFillBlack);
    i++;
}

void EdgeFill::select_item(void){

    if(current_item == EdgeFillNone){
        this->setCurrentIndex(EdgeFillNone);
    }else if(current_item == EdgeFillWhite) {
        this->setCurrentIndex(EdgeFillWhite);
    }else {
        this->setCurrentIndex(EdgeFillBlack);
    }
}

void EdgeFill::item_event(int value, INT_SETTING_VALUE* edge_fill_para)
{
    QVariant select_item = this->itemData(value);

    if(select_item == EdgeFillNone){
        edge_fill_para->select = current_item = EdgeFillNone;
    }else if(select_item == EdgeFillWhite){
        edge_fill_para->select = current_item = EdgeFillWhite;
    }else {
        edge_fill_para->select = current_item = EdgeFillBlack;
    }

    changed = true;
}

void EdgeFill::item_event_options(void){

}
