#ifndef EDGEFILL_H
#define EDGEFILL_H

#include <QComboBox>
#include "supervisor.h"
#include "edgecorrectionsettingsdialog.h"

class EdgeFill : public QComboBox
{
public:
    bool changed;
    int current_item;

    EdgeFill(QWidget *parent = 0);

    void initialize(SCANPARA edge_fill_para);

    void update_ui(INT_SETTING_VALUE edge_fill_para, QLabel* label1, QLabel* label2);

    void item_event(int value, INT_SETTING_VALUE* edge_fill_para);

    void item_event_options(void);

private:
    void add_item();

    void select_item(void);
};

#endif // EDGEFILL_H
