#include "edgecorrectionsettingsdialog.h"
#include "ui_edgecorrectionsettingsdialog.h"

EdgeCorrectionSettingsDialog::EdgeCorrectionSettingsDialog(SCANPARA device_data, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EdgeCorrectionSettingsDialog)
{
    ui->setupUi(this);
    ui->EdgeFill_comb->addItem(TranslationString::GetString().translation_str.ADVANCEDSETTING_041, EdgeFillNone);
    ui->EdgeFill_comb->addItem(TranslationString::GetString().translation_str.ADVANCEDSETTING_042, EdgeFillWhite);
    ui->EdgeFill_comb->addItem(TranslationString::GetString().translation_str.ADVANCEDSETTING_043, EdgeFillBlack);
    m_settings = device_data;

    if (m_settings.DeficiencyCorrection.capability.supportLevel != kSDISupportLevelNone)
    {
        ui->TearCorrection_checkBox->setVisible(true);
        ui->TearCorrection_checkBox->setChecked(m_settings.DeficiencyCorrection.select);
    } else {
        ui->TearCorrection_checkBox->setVisible(false);
        ui->TearCorrection_checkBox->setChecked(false);
    }

    connect(ui->OK_pushButton, &QPushButton::clicked, this, &EdgeCorrectionSettingsDialog::accept);

    connect(ui->Cancel_pushButton, &QPushButton::clicked, this, &EdgeCorrectionSettingsDialog::reject);

    this->updateUI();
}

EdgeCorrectionSettingsDialog::~EdgeCorrectionSettingsDialog()
{
    delete ui;
}


void EdgeCorrectionSettingsDialog::SetValue()
{
    m_settings.DeficiencyCorrection.select = ui->TearCorrection_checkBox->isChecked();
    m_settings.edgeFill.select = ui->EdgeFill_comb->currentIndex();
    m_settings.edgeFillVolumeLeft = ui->EdgeFillLevelLeft_spinBox->value() * 10;
    m_settings.edgeFillVolumeRight = ui->EdgeFillLevelRight_spinBox->value() * 10;
    m_settings.edgeFillVolumeTop = ui->EdgeFillLevelTop_spinBox->value() * 10;
    m_settings.edgeFillVolumeBottom = ui->EdgeFillLevelBottom_spinBox->value() * 10;
}

void EdgeCorrectionSettingsDialog::GetValue(SCANPARA* device_data)
{
    device_data->DeficiencyCorrection.select = m_settings.DeficiencyCorrection.select;
    device_data->edgeFill.select = m_settings.edgeFill.select;
    device_data->edgeFillVolumeLeft = m_settings.edgeFillVolumeLeft;
    device_data->edgeFillVolumeRight = m_settings.edgeFillVolumeRight;
    device_data->edgeFillVolumeTop = m_settings.edgeFillVolumeTop;
    device_data->edgeFillVolumeBottom = m_settings.edgeFillVolumeBottom;
}

void EdgeCorrectionSettingsDialog::updateUI(){
    ui->TearCorrection_checkBox->setChecked(m_settings.DeficiencyCorrection.select);
    ui->EdgeFill_comb->setCurrentIndex(m_settings.edgeFill.select);
    ui->EdgeFillLevelLeft_spinBox->setValue(m_settings.edgeFillVolumeLeft / 10.0);
    ui->EdgeFillLevelRight_spinBox->setValue(m_settings.edgeFillVolumeRight / 10.0);
    ui->EdgeFillLevelTop_spinBox->setValue(m_settings.edgeFillVolumeTop / 10.0);
    ui->EdgeFillLevelBottom_spinBox->setValue(m_settings.edgeFillVolumeBottom / 10.0);
}
